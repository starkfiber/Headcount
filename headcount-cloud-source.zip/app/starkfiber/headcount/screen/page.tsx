import type {Metadata} from 'next';
import {SessionParticipant} from '../classrooms';
export const metadata:Metadata={title:'Classroom screen | Headcount by SFE',robots:{index:false,follow:false}};
export default function Page(){return <SessionParticipant screenMode/>;}
