import type {Metadata} from 'next';
import {TeacherWorkspace} from '../classrooms';
export const metadata:Metadata={title:'Your classrooms | Headcount by SFE',robots:{index:false,follow:false}};
export default function Page(){return <TeacherWorkspace/>;}
