import type {Metadata} from 'next';
import {SessionParticipant} from '../classrooms';
export const metadata:Metadata={title:'Join your classroom | Headcount by SFE',robots:{index:false,follow:false}};
export default function Page(){return <SessionParticipant/>;}
