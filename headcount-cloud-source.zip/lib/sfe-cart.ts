import {isKitProductPath} from './sfe-kit-product-pages';
import products from '../content/sfe-shop.json';
export const cartKey='sfe-toolkit-cart-v1';
export function cartIds(value:unknown):string[]{return Array.isArray(value)?[...new Set(value.filter((id):id is string=>typeof id==='string'&&products.some(p=>p.id===id)))].slice(0,20):[];}
export function purchaseReturn(value:string|null){return value==='/shop?cart=1'?value:null;}

export const pendingCartKey='sfe-toolkit-checkout-v1';
export type PendingCart={requestId:string;created:number};
/** Only request identity is persisted. Billing details and payment links stay out of storage. */
export function pendingCart(value:unknown,now=Date.now()):PendingCart|null{
 if(!value||typeof value!=='object')return null;
 const p=value as Partial<PendingCart>;
 return typeof p.requestId==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(p.requestId)&&typeof p.created==='number'&&Number.isFinite(p.created)&&p.created<=now&&now-p.created<30*86400000?{requestId:p.requestId,created:p.created}:null;
}

export function newPendingCart(requestId:string):PendingCart{return {requestId,created:Date.now()};}
export function workspaceReturn(value:string|null){if(/^\/headcount\/classroom(?:\?remote=[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})?$/.test(value||''))return value;if(/^\/kit\/scout(?:\/(?:compare|stacks|connect|plans))?$/.test(value||''))return value;if(value&&isKitProductPath(value))return value;return (/^\/kit(?:\/library|\/connect|\/arsenal|\/orders(?:\/[a-f0-9]{64})?)?$/.test(value||'')?value:null)||(/^\/apps\/(?:sfebook|proofmark|roomledger|stockwell|claimwell|billhead|quicklearn|youagetoo|myjob|financewill)$/.test(value||'')?value:null)||(/^\/tags\/jobs\?job=[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value||'')?value:null)||(/^\/tags\/saved(?:\?save=[a-z0-9]+(?:-[a-z0-9]+)*)?$/.test(value||'')?value:null)||purchaseReturn(value)||((/^\/company-pack(?:\?invite=[a-f0-9]{64})?$/.test(value||'')||['/tags','/tags/join','/tags/requests','/roomledger','/claimwell','/billhead','/quicklearn','/myjob','/financewill','/youagetoo','/proofmark','/apps','/sfebook/bill-check','/stockwell','/documents','/book','/business','/business/orders','/cast','/admin','/tags/runner','/tags/home','/tags/desk','/tags/desk?enrol=1','/tags/jobs','/tags/activate'].includes(value||''))?value:null);}
