# Headcount cloud integration source
MIT license; copyright 2026 Stark Fiber Enterprise. See LICENSE.

Target runtime: Node 24 (node:sqlite), Next.js 16, React 19, Zod 4, Vitest 4. The pure service accepts DatabaseSync and is independently testable. Host must enable PRAGMA foreign_keys=ON, protect the database directory and provide durable storage/backups.

Required host adapters: lib/sfe-hub-db exports hubDb():DatabaseSync and hubLimit(key,max,window?):boolean; lib/sfe-hub-auth exports sfeUser(headers) returning current non-disabled user or null, hubOrigin(), and isHubHost(request). lib/sfe-hub-validation exports bounded readHubJson(request,maxBytes). Wire the API only on your authorized origin and preserve same-origin write checks. Use secure existing account authentication, never a client-provided owner ID.

Expose app/starkfiber/headcount routes under /headcount with your route mapping. Add /headcount/classroom to your safe authentication return allowlist. Serve approved artwork at /starkfiber/headcount/{classroom,attendance,join,quiz,results}.webp or replace Art with licensed local assets. SFE artwork is not included in this code-only archive.

Run tests/sfe-headcount.test.ts with Vitest and Node 24. Client code is original SFE work. No proprietary Kahoot source or assets are included. No environment files, secrets, logs, accounts or classroom data are included.

Classroom identity: self-hosted Nunito font under SIL OFL, included with its licence. The Headcount layout imports the local font and identity.css; preserve these when integrating. The route-scoped identity replaces the corporate navigation only on Headcount. No hosted Google Fonts request is required.
